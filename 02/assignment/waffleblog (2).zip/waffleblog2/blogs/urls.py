from django.urls import path
from . import views

urlpatterns = [
    path("", views.IndexView.as_view(), name="index"),
    path("blogs/<int:blog_id>/", views.blogDetail, name="blog-detail"),
    path("blogs/<int:blog_id>/edit/", views.BlogUpdateView.as_view(), name="blog-update"),
    path("blogs/<int:blog_id>/delete/", views.BlogDeleteView.as_view(), name="blog-delete"),
    path("blogs/<int:blog_id>/comment/<int:comment_id>/delete", views.commentDelete, name="comment-delete"),
    path("blogs/new/", views.BlogCreateView.as_view(), name="blog-create"),
]