from django.shortcuts import render, get_object_or_404, redirect
from allauth.account.views import PasswordChangeView
from django.urls import reverse
from django.views.generic import ListView , DetailView, CreateView, UpdateView, DeleteView
from .models import Blog , Comment
from .forms import BlogForm, CommentForm
from braces.views import LoginRequiredMixin, UserPassesTestMixin
from django.http import Http404

# Create your views here.
class CustomPasswordChangeView(PasswordChangeView):
    def get_success_url(self):
        return reverse("index")
    
class IndexView(ListView):
    model = Blog
    template_name = "blogs/index.html"
    context_object_name = "blogs"
    ordering = ["-dt_created"]

def blogDetail(request, blog_id):
    blog = get_object_or_404(Blog, pk=blog_id)
    comments = Comment.objects.filter(blog = blog_id).order_by('dt_created')
    if request.method == "POST" and request.POST['content'] != "":
        commnet = Comment()
        commnet.blog = blog
        commnet.content = request.POST['content']
        commnet.author = request.user
        commnet.save()
        return redirect('blog-detail', blog_id)

    return render(request, "blogs/blog_detail.html", {'blog' : blog, 'comments':comments,})


class BlogUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Blog
    form_class = BlogForm
    template_name = "blogs/blog_form.html"
    pk_url_kwarg = "blog_id"
    
    raise_exception = True

    def get_success_url(self):
        return reverse("blog-detail", kwargs={"blog_id" : self.object.id})

    def test_func(self, user):
        return self.get_object().author == user or user.is_superuser

class BlogCreateView(LoginRequiredMixin, CreateView):
    model = Blog
    form_class = BlogForm
    template_name = "blogs/blog_form.html"

    raise_exception = True

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)
    
    def get_success_url(self):
        return reverse("blog-detail", kwargs={"blog_id" : self.object.id})
    
class BlogDeleteView(LoginRequiredMixin , UserPassesTestMixin, DeleteView):
    model = Blog
    template_name = "blogs/blog_confirm_delete.html"
    pk_url_kwarg = "blog_id"

    raise_exception = True

    def get_success_url(self):
        return reverse("index")
    
    def test_func(self, user):
        return self.get_object().author == user or user.is_superuser

def commentDelete(request, blog_id, comment_id):
    comment = get_object_or_404(Comment, pk=comment_id)
    if request.user != comment.author : 
        return Http404("You can't delete other user's comment")
    comment.delete()
    return redirect('blog-detail', blog_id)