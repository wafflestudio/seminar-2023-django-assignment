# Portfolio project

## Requirements
- python 3.7.10
- install dependencies: `pip install -r requirements.txt`