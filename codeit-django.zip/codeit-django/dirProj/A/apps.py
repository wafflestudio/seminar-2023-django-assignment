from django.apps import AppConfig


class AConfig(AppConfig):
    name = 'A'
