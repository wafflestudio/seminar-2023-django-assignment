from django import forms 
from .models import User, Blog, Comment


class SignupForm(forms.ModelForm):
    class Meta :
        model = User
        fields = '__all__'

    #def signup(self, request, user):
    #    user.nickname = self.cleaned_data["nickname"]
    #    user.save()


class BlogForm(forms.ModelForm):
    class Meta:
        model = Blog
        fields = [
            "title",
            "content",
        ]

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        exclude = ('article', 'user',)


