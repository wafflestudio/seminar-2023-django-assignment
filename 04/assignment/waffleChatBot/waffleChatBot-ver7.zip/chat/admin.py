from django.contrib import admin
from .models import Character, Chat

# Register your models here.
admin.site.register(Character)
admin.site.register(Chat)