from django.contrib import admin
from foods.models import Menu
# Register your models here.
admin.site.register(Menu)