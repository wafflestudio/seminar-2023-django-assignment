from django.apps import AppConfig


class WblogConfig(AppConfig):
    name = 'wblog'
